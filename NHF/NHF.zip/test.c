//
// Created by sziha on 25/10/2023.
//

struct test{
    int a;
};
typedef struct{
    int b;
} test_t;