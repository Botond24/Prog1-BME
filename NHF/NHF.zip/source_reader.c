//
// Created by sziha on 21/10/2023.
//

#include "source_reader.h"

node_t *read_source(char *filename){
    FILE *fp = fopen(filename, "r");
    if (fp == NULL) {
        fprintf(stderr, "Unable to open file %s\n", filename);
        return NULL;
    }
    node_t *first_node = (node_t *) malloc(sizeof(node_t));
    node_t *current_node = first_node;
    current_node->type = -1;
    char buffer[1000];
    int skip = 0;
    int c = 0;
    int c_bracket[2] = {0,0};
    for (int i = 0; c != EOF; i = (i == 999) ? 0 : i + 1) {
        c = getc(fp);
        if (skip == 1 && c != '\n') {
            continue;
        }
        if (c == '{')
        {
            c_bracket[1] = c_bracket[0];
            c_bracket[0]++;
        }
        else if (c == '}')
        {
            c_bracket[1] = c_bracket[0];
            c_bracket[0]--;
        }
        skip = 0;
        buffer[i] = (char) c;
        buffer[i + 1] = '\0';
        if (buffer[i] == '#' || buffer[i] == '\n' || (i > 1 && (buffer[i-1] == '/' && buffer[i] == '/'))) {
            i--;
            skip = 1;
            if (i > 1 && (buffer[i-1] == '/' && buffer[i] == '/')) i--;
            continue;
        }
        fprintf(stderr,"%s", buffer);
        switch (current_node->type) {
            case structs:
                if (current_node->name[0] == '\0') {
                    if (c_bracket[0] == 1)
                        i = 0;
                    if (c_bracket[0] == 0 && c_bracket[1] == 1) {
                        if (c != ';') continue;
                        char *name = substr(buffer, '}', ';');
                        if (name == NULL) continue;
                    }
                }
                break;
            default:
                if (strstr(buffer, "struct") != NULL) {
                    printf("test");
                    current_node->type = structs;
                    if (sscanf(buffer,"struct %s", current_node->name) != 1) { //struct name
                        if (sscanf(buffer, "struct %s{", current_node->name) != 1) current_node->name[0] = '\0'; //struct name{
                    }
                }
                break;
        }
    }
    fclose(fp);
    return first_node;
}

char* substr(char const *str, char start, char end) {
    char* s = strchr(str, start);
    char* e = strchr(str, end);
    if (s == NULL || e == NULL)
        return NULL;
    char* result = malloc((e - s) + 1);
    if (result == NULL)
        return NULL;
    strncpy(result, s, e-s);
    result[e-s+1] = '\0';
    return result;
}
